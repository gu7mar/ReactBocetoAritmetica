import React, {Component} from 'react';

class FrontPage extends Component{
    render(){
        return(<h1>Presentacion de los cursos</h1>);
    }
}

export default FrontPage;