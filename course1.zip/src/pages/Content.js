import React, {Component} from 'react';

class Content extends Component{
    render(){
        return(<h1>contenido</h1>);
    }
}

export default Content;